package cn.itcast_10;

public class ThreadDemo {
	public static void main(String[] args) {
		// StringBuffer/StringBuilder
		// StringBuffer;
		// StringBuilder

		// Vector/ArrayList
		// Vector
		// ArrayList

		// Hashtable/HashMap
		// java.util.Hashtable;
		// HashMap;
	}
}
