package cn.itcast_03;

public class Student {
	String name;
	int age;
}
