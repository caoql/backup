package cn.itcast_02;

public class InterTest {
	public static void main(String[] args) {
		
	}
}
