package cn.itcast;

public class Test {
	public static void main(String[] args) {
		Father f = new Father();
		//f.show();
		f.show2();
		f.show3();
		f.show4();
	}
}