/*
class Person {
	protected String name;
}

class Student extends Person {
	public Student() {
		this.name = "hello";
	}
}
*/

public class HelloWorld 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
